define(['jquery',
    'core/ajax',
    'core/templates',
    'core/notification'],
        function ($,
                ajax,
                templates,
                notification) {
            return /** @alias module:quiz_participation/quiz */ {
                /**
                 * Load the user programs!
                 *
                 * @method programs
                 */
                users: function () {
                    // Add a click handler to the button.
                    $(document).on('click', '.page-link', function (e) {
                        e.preventDefault();
                        var page_val = $(this).attr('href');
                        var cid = getURLParameter('cid', page_val);
                        var learnername = $('.learner-search').val();
                        var page = getURLParameter('page', page_val);
                        if (page) {
                            var WAITICON = {'pix': M.util.image_url("i/loading", 'core'), 'component': 'moodle'};
                            var loader = $('<img />')
                                    .attr('src', M.util.image_url(WAITICON.pix, WAITICON.component))
                                    .addClass('spinner');
                            $('.alllearners-display').html('<div class="text-center">' + loader.get(0).outerHTML + '</div>');
                            var promises = ajax.call([{
                                    methodname: 'block_quiz_participation_get_all_learners',
                                    args: {
                                        courseid: cid,
                                        page: page,
                                        learnername: learnername
                                    }
                                }]);
                            promises[0].done(function (data) {
                                $('.alllearners-display').html(data.displayhtml);
                            }).fail(notification.exception);
                            //     }) 
                        } else {
                            return false;
                        }
                    });
                    // Add a click handler to the button.
                    $(document).on('change', '#program-list', function (e) {
                        e.preventDefault();
                        var cid = $("#program-list :selected").val();

                        var WAITICON = {'pix': M.util.image_url("i/loading_small", 'core'), 'component': 'moodle'};
                        var loader = $('<img />')
                                .attr('src', M.util.image_url(WAITICON.pix, WAITICON.component))
                                .addClass('spinner');
                        $('.course-data').html('<div class="text-center">' + loader.get(0).outerHTML + '</div>');
                        var promises = ajax.call([{
                                methodname: 'block_quiz_participation_get_course_participants',
                                args: {
                                    courseid: cid,
                                }
                            }]);
                        promises[0].done(function (data) {
                            $('.course-data').html(data.displayhtml);
                        }).fail(notification.exception);
                    });
                    // Add a click handler to the button.
                    $(document).on('keyup', '.learner-search', delay(function (e) {
                        e.preventDefault();
                        var page_val = window.location.href;
                        var cid = getURLParameter('cid', page_val);
                        var learnername = $('.learner-search').val();
//                        if (learnername) {
                        var WAITICON = {'pix': M.util.image_url("i/loading", 'core'), 'component': 'moodle'};
                        var loader = $('<img />')
                                .attr('src', M.util.image_url(WAITICON.pix, WAITICON.component))
                                .addClass('spinner');
                        $('.alllearners-display').html('<div class="text-center">' + loader.get(0).outerHTML + '</div>');
//                        alert(learnername);
                        var promises = ajax.call([{
                                methodname: 'block_quiz_participation_get_all_learners',
                                args: {
                                    courseid: cid,
                                    page: 0,
                                    learnername: learnername
                                }
                            }]);
                        promises[0].done(function (data) {
                            $('.alllearners-display').html(data.displayhtml);
                        }).fail(notification.exception);
                        //     }) 
//                        } else {
//                            return false;
//                        }
                    }, 1000));
                }

            };

            function getURLParameter(name, page_val) {
                return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(page_val) || [null, ''])[1].replace(/\+/g, '%20')) || null;
            }
            //Function for delay the keyup event
            function delay(callback, ms) {
                var timer = 0;
                return function () {
                    var context = this, args = arguments;
                    clearTimeout(timer);
                    timer = setTimeout(function () {
                        callback.apply(context, args);
                    }, ms || 0);
                };
            }
        });
