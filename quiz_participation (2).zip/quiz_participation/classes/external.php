<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace block_quiz_participation;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/externallib.php');

use external_api;
use external_function_parameters;
use external_value;
use external_multiple_structure;
use external_single_structure;
use moodle_url;
use context_system;
use context_course;
use html_writer;

class external extends external_api {

    /**
     * defines parameters to be passed in ws request
     */
    public static function get_all_learners_parameters() {
        return new external_function_parameters(
                array(
            'courseid' => new external_value(PARAM_INT, 'The page', VALUE_OPTIONAL),
            'page' => new external_value(PARAM_INT, 'The page', VALUE_OPTIONAL),
            'learnername' => new external_value(PARAM_TEXT, 'Learner name', VALUE_OPTIONAL),
                )
        );
    }

    /**
     * Return the learning path info
     * @return array Learning path array
     */
    public static function get_all_learners($courseid = 0, $page = 0, $learnername = null) {
        global $DB, $CFG, $OUTPUT, $PAGE;
        require_once $CFG->dirroot . '/blocks/quiz_participation/lib.php';
        $params = self::validate_parameters(self::get_all_learners_parameters(),
                        array('courseid' => $courseid, 'page' => $page, 'learnername' => $learnername));
        $perpage = 10;
        $page = $params['page'];
        $context = \context_system::instance();
        $PAGE->set_context($context);
        $where = '';
        if (!empty($params['learnername'])) {
            $where = "  concat(u.firstname,' ',u.lastname) LIKE concat('%','" . $params['learnername'] . "','%')";
        }

        $quizmodule = $DB->get_record('modules', ['name' => 'quiz']);
        if (empty($quizmodule)) {
            return $this->content;
        }

        $quizids = [];
        foreach (get_fast_modinfo($params['courseid'])->cms as $cm) {
            if ($cm->module === $quizmodule->id && $cm->uservisible === true) {
                $quizids[] = $cm->instance;
            }
        }
        $output = '';
        $coursecontext = \CONTEXT_COURSE::instance($params['courseid']);
        $enrolledusers = get_role_users(5, $coursecontext, false, '*,u.id', "u.id ASC", true, '', $page * $perpage, $perpage, $where);
        $countenrolledusers = get_role_users(5, $coursecontext, false, '*,u.id', "u.id ASC", true, '', '', '', $where);
        $today = time();
        $start = (date('w', $today) == 0) ? $today : strtotime('last friday', $today);
        $weekstart = date('Y-m-d', $start);
        $weekenddate = strtotime('next friday', $start);

        if (!empty($enrolledusers)) {
            $i = 0;
            $learners = array();
            foreach ($enrolledusers as $key => $user) {
                $userpic = new \user_picture($user);
                $imgurl = $userpic->get_url($PAGE);
                $attempts = get_course_quiz_participation_count($quizids, $user->id, $start, $weekenddate);
                $learners['trainers'][$i]['name'] = $user->firstname . ' ' . $user->lastname;
                $learners['trainers'][$i]['email'] = $user->email;
                $learners['trainers'][$i]['imageurl'] = "$imgurl";
                $learners['trainers'][$i]['quizcount'] = $attempts->noofquiz;
                $learners['trainers'][$i]['totalquiz'] = count($quizids);
                $i++;
            }
            array_multisort(array_column($learners['trainers'], 'quizcount'), SORT_DESC, $learners['trainers']);
            $output .= html_writer::start_div('alllearners-display');
            $output .= $OUTPUT->render_from_template('block_quiz_participation/alluser', $learners);
            $url_params = array("cid" => $params['courseid']);
            $url = new moodle_url('/blocks/quiz_participation/allusers.php', $url_params);
            $output .= html_writer::start_div('pagination-nav-filter');
            $output .= $OUTPUT->paging_bar(count($countenrolledusers), $page, $perpage, $url);
            $output .= html_writer::end_div();
            $output .= html_writer::end_div();
        } else {
            $output = html_writer::div(get_string('nothingtodisplay', 'block_quiz_participation'), 'alert alert-info mt-3');
        }
        $html = array();
        $html['displayhtml'] = $output;
        return $html;
    }

    /**
     * returns leaders info in json format
     */
    public static function get_all_learners_returns() {
        return $data = new external_single_structure([
            'displayhtml' => new external_value(PARAM_RAW, 'html')
        ]);
    }
    
    
    /**
     * defines parameters to be passed in ws request
     */
    public static function get_course_participants_parameters() {
        return new external_function_parameters(
                array(
                    'courseid' => new external_value(PARAM_INT, 'Courseid', VALUE_OPTIONAL),  
                )
        );
    }

    /**
     * Return the learning path info
     * @return array Learning path array
     */
    public static function get_course_participants($courseid = 0) {
        global $DB, $CFG, $OUTPUT, $PAGE;
        require_once $CFG->dirroot . '/blocks/quiz_participation/lib.php';
        $params = self::validate_parameters(self::get_course_participants_parameters(),
                        array('courseid' => $courseid));
        $perpage = 10;
        $context = \context_system::instance();
        $PAGE->set_context($context);
       
        $quizmodule = $DB->get_record('modules', ['name' => 'quiz']);
        if (empty($quizmodule)) {
//            return $this->content;
        }

        $quizids = [];
        foreach (get_fast_modinfo($params['courseid'])->cms as $cm) {
            if ($cm->module === $quizmodule->id && $cm->uservisible === true) {
                $quizids[] = $cm->instance;
            }
        }
        $output = '';
        $coursecontext = \CONTEXT_COURSE::instance($params['courseid']);
        $enrolledusers = get_role_users(5, $coursecontext, false, '*,u.id', "u.id ASC");
            //Programs start this week
            $today = time();
            $start = (date('w', $today) == 0) ? $today : strtotime('last friday', $today);
            $weekstart = date('Y-m-d', $start);
            $weekenddate = strtotime('next friday', $start);
            if (!empty($enrolledusers)) {
                $i = 0;
                $learners = array();
                foreach ($enrolledusers as $key => $user) {
                    $userpic = new \user_picture($user);
                    $imgurl = $userpic->get_url($PAGE);
                    $attempts = get_course_quiz_participation_count($quizids, $user->id, $start, $weekenddate);
                    $learners['trainers'][$i]['name'] = $user->firstname . ' ' . $user->lastname;
                    $learners['trainers'][$i]['imageurl'] = "$imgurl";
                    $learners['trainers'][$i]['profileurl'] = $CFG->wwwroot . "/user/profile.php?id=" . $user->id;
                    $learners['trainers'][$i]['quizcount'] = $attempts->noofquiz;
                    $learners['trainers'][$i]['totalquiz'] = count($quizids);
                    $i++;
                }
                array_multisort(array_column($learners['trainers'], 'quizcount'), SORT_DESC, $learners['trainers']);
                 $learners['headerdisplay'] = true;
                $output .= $OUTPUT->render_from_template('block_quiz_participation/learners', $learners);
            } else {
                $output .= html_writer::div(get_string('nothingtodisplay', 'block_quiz_participation'), 'alert alert-info mt-3'); 
            }   
        $html = array();
        $html['displayhtml'] = $output;
        return $html;
    }

    /**
     * returns leaders info in json format
     */
    public static function get_course_participants_returns() {
        return $data = new external_single_structure([
            'displayhtml' => new external_value(PARAM_RAW, 'html')
        ]);
    }

}
