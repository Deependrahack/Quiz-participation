<?php


$functions = array(
    'block_quiz_participation_get_all_learners' => array(
        'classpath' => '',
        'classname' => 'block_quiz_participation\external',
        'methodname' => 'get_all_learners',
        'description' => 'Return list of all learners in the course',
        'type' => 'read',
         'ajax'        => true,
        'capabilities' => '',
    ),
    'block_quiz_participation_get_course_participants' => array(
        'classpath' => '',
        'classname' => 'block_quiz_participation\external',
        'methodname' => 'get_course_participants',
        'description' => 'Return list of all learners in the course',
        'type' => 'read',
         'ajax'        => true,
        'capabilities' => '',
    )
);